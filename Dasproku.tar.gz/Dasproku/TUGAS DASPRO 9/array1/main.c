#include <stdio.h>
#include <stdlib.h>

// Nama = Husin Sufi
// NIM = A11.2018.10909
// Kelompok = A11.4102

int main()
{
    printf("cetak array of integer\n");
    int ar1[10] = {2,6,1,12,5,4,7,3,26,50};

    printf("%d\n",ar1[0]);
    printf("%d\n",ar1[1]);
    printf("%d\n",ar1[2]);
    printf("%d\n",ar1[3]);
    printf("%d\n",ar1[4]);
    printf("%d\n",ar1[5]);
    printf("%d\n",ar1[6]);
    printf("%d\n",ar1[7]);
    printf("%d\n",ar1[8]);
    printf("%d\n",ar1[9]);

     printf("\n\ncetak array of Float\n");
    float ar2[10] = {2.4,4.6,11.3,2.16,8.12,3.52,9.45,4.32,6.64,12.10};
    printf("%.2f\n",ar2[0]);
    printf("%.2f\n",ar2[1]);
    printf("%.2f\n",ar2[2]);
    printf("%.2f\n",ar2[3]);
    printf("%.2f\n",ar2[4]);
    printf("%.2f\n",ar2[5]);
    printf("%.2f\n",ar2[6]);
    printf("%.2f\n",ar2[7]);
    printf("%.2f\n",ar2[8]);
    printf("%.2f\n",ar2[9]);

     printf("\n\ncetak array of Char\n");
    char ar3[10] = {'H','U','S','E','I','N','S','U','F','I'};
    printf("%c\n",ar3[0]);
    printf("%c\n",ar3[1]);
    printf("%c\n",ar3[2]);
    printf("%c\n",ar3[3]);
    printf("%c\n",ar3[4]);
    printf("%c\n",ar3[5]);
    printf("%c\n",ar3[6]);
    printf("%c\n",ar3[7]);
    printf("%c\n",ar3[8]);
    printf("%c\n",ar3[9]);



     return 0;
}
