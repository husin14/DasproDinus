

#include <stdio.h>
#include <stdlib.h>

// Nama = Husin Sufi
// NIM = A11.2018.10909
// Kelompok = A11.4102

int main()
{
    int a;  //// int a sebagai iterator

    printf("perulangan dengan menggunakan FOR\n");

    for (a=1; a<=7; a++) ////i=0 sebagai inisialisasi nilai awal dan i<=7 sebagai batasan perulangan i++ sebagai pembaruan nilai

    {
        printf("perulangan ke-%d\n",a);
    }

    return 0;
}
