#include <stdio.h>
#include <stdlib.h>

// Nama = Husin Sufi
// NIM = A11.2018.10909
// Kelompok = A11.4102

int main()
{
    int x,y;

    for (x=1; x<7; x++) ///OUTER LOOP
{


    for (y=1;y<7;y++) ///INNER LOOP
    {


       printf(" %d%d ",x,y);
    }
        printf("\n");
}

    return 0;
}
