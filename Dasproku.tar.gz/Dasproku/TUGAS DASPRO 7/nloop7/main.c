#include <stdio.h>
#include <stdlib.h>

// Nama = Husin Sufi
// NIM = A11.2018.10909
// Kelompok = A11.4102

int main()
{
    int x,y;

x=1;
while (x<=7)
{
       printf("\t\t perulangan ke- %d\n",x);

    for (y=1; y<=5; y++)
    {
         printf("angka ke- %d\n",y);

    }
    x=x+1;

}
    return 0;
}
