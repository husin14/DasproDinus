#include <stdio.h>
#include <stdlib.h>

// Nama = Husin Sufi
// NIM = A11.2018.10909
// Kelompok = A11.4102

int main()
{
    int x,y;
x=1;
do
{
       printf("\t\t perulangan ke- %d\n",x);
       x=x+1;



   for (y=1; y<=5; y++)
   {
       printf("angka ke %d\n",y);
   }


}
while (x<=7);

    return 0;
}

