#include <stdio.h>
#include <stdlib.h>
    /*Nama : Husin Sufi
  NIM  : A11.2018.10909
  Kelas: A11.4012
*/

int main(){
int i,j,k;
printf("i\tj\tk\n");
for(i=1,j=50;i<=50,j>=1;i++,j--){
k=i-j;
printf("%d\t%d\t%d\n",i,j,k);
}
return 0;
}
