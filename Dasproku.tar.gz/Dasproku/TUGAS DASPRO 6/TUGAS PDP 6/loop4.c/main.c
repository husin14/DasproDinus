#include <stdio.h>
#include <stdlib.h>
    /*Nama : Husin Sufi
  NIM  : A11.2018.10909
  Kelas: A11.4012
*/


int main()
{
int i,j;
printf("masukkan jumlah data:");
scanf("%d",&i);
for(j=1;j<=i;j++){
printf("%d\n",j);
}
return 0;
}
