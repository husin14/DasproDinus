#include <stdio.h>
#include <stdlib.h>
    /*Nama : Husin Sufi
  NIM  : A11.2018.10909
  Kelas: A11.4012
*/


int main()
{
int i,j;
for(i=1;i<=10;i++){
printf("masukkan angka %d:   ",i);
scanf("%d",&j);
}
return 0;
}
