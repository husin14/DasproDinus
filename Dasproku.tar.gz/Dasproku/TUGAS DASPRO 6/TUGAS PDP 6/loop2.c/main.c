#include <stdio.h>
#include <stdlib.h>
      /*Nama : Husin Sufi
  NIM  : A11.2018.10909
  Kelas: A11.4012
*/

int main()
{
int i;
printf("i\n");
for(i=0;i<=100;i=i+2){
printf("%d\n",i);
}
return 0;
}
